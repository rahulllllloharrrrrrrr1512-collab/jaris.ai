import 'package:flutter/material.dart';

class JarvisColors {
  static const background = Color(0xFF02060D);
  static const panel = Color(0xFF0A1A2B);
  static const cyan = Color(0xFF00E5FF);
  static const cyanDim = Color(0xFF0B7C8C);
  static const amber = Color(0xFFFFB300);
}

ThemeData jarvisTheme() {
  return ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: JarvisColors.background,
    colorScheme: const ColorScheme.dark(
      primary: JarvisColors.cyan,
      surface: JarvisColors.panel,
    ),
    textTheme: const TextTheme(
      bodyMedium: TextStyle(color: Colors.white70, letterSpacing: 0.5),
    ),
  );
}
