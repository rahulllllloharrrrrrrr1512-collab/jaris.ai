import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../core/theme.dart';

enum OrbState { idle, listening, thinking, speaking }

class JarvisOrb extends StatefulWidget {
  final OrbState state;
  final double size;
  const JarvisOrb({super.key, required this.state, this.size = 280});

  @override
  State<JarvisOrb> createState() => _JarvisOrbState();
}

class _JarvisOrbState extends State<JarvisOrb>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: const Duration(seconds: 6))
      ..repeat();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: widget.size,
      height: widget.size,
      child: CustomPaint(painter: _OrbPainter(_c, widget.state)),
    );
  }
}

class _OrbPainter extends CustomPainter {
  final Animation<double> anim;
  final OrbState state;
  _OrbPainter(this.anim, this.state) : super(repaint: anim);

  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero);
    final base = size.width * 0.28;
    final t = anim.value * 2 * math.pi;

    final (pulseSpeed, amp, spin, color) = switch (state) {
      OrbState.idle => (2.0, 0.03, 1.0, JarvisColors.cyan),
      OrbState.listening => (6.0, 0.09, 2.0, JarvisColors.cyan),
      OrbState.thinking => (4.0, 0.05, 6.0, JarvisColors.amber),
      OrbState.speaking => (10.0, 0.12, 2.0, JarvisColors.cyan),
    };
    final pulse = 1 + amp * math.sin(t * pulseSpeed);
    final r = base * pulse;

    // Outer glow
    canvas.drawCircle(
      center,
      r * 2.2,
      Paint()
        ..shader = RadialGradient(colors: [
          color.withOpacity(0.35),
          color.withOpacity(0.0),
        ]).createShader(Rect.fromCircle(center: center, radius: r * 2.2)),
    );

    // Core
    canvas.drawCircle(
      center,
      r,
      Paint()
        ..shader = RadialGradient(colors: [
          Colors.white,
          color,
          color.withOpacity(0.2),
        ], stops: const [
          0.0,
          0.45,
          1.0
        ]).createShader(Rect.fromCircle(center: center, radius: r)),
    );

    // Rotating rings
    for (var i = 0; i < 3; i++) {
      final rr = r * (1.5 + i * 0.4);
      final dir = i.isEven ? 1 : -1;
      final start = t * spin * dir + i * 1.3;
      final paint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.0 - i * 0.4
        ..strokeCap = StrokeCap.round
        ..color = color.withOpacity(0.8 - i * 0.2);
      for (var a = 0; a < 3; a++) {
        canvas.drawArc(
          Rect.fromCircle(center: center, radius: rr),
          start + a * (2 * math.pi / 3),
          0.9,
          false,
          paint,
        );
      }
    }
  }

  @override
  bool shouldRepaint(covariant _OrbPainter old) => old.state != state;
}
