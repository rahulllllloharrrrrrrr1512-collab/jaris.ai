import 'package:flutter/material.dart';
import 'package:speech_to_text/speech_to_text.dart';
import '../../core/theme.dart';
import '../../widgets/jarvis_orb.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final SpeechToText _speech = SpeechToText();
  bool _ready = false;
  OrbState _orb = OrbState.idle;
  String _transcript = '';
  String _status = 'ONLINE. AWAITING YOUR COMMAND, SIR.';

  @override
  void initState() {
    super.initState();
    _initSpeech();
  }

  Future<void> _initSpeech() async {
    final ok = await _speech.initialize(
      onStatus: (s) {
        if ((s == 'done' || s == 'notListening') && mounted) {
          setState(() {
            _orb = OrbState.idle;
            _status = 'ONLINE. AWAITING YOUR COMMAND, SIR.';
          });
        }
      },
      onError: (e) {
        if (mounted) {
          setState(() {
            _orb = OrbState.idle;
            _status = 'AUDIO ERROR: ${e.errorMsg}';
          });
        }
      },
    );
    if (mounted) {
      setState(() {
        _ready = ok;
        if (!ok) _status = 'MICROPHONE OR SPEECH SERVICE UNAVAILABLE.';
      });
    }
  }

  Future<void> _toggleListen() async {
    if (!_ready) {
      await _initSpeech();
      return;
    }
    if (_speech.isListening) {
      await _speech.stop();
      return;
    }
    setState(() {
      _orb = OrbState.listening;
      _status = 'LISTENING...';
      _transcript = '';
    });
    await _speech.listen(
      onResult: (r) {
        if (!mounted) return;
        setState(() => _transcript = r.recognizedWords);
      },
    );
  }

  @override
  void dispose() {
    _speech.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment(0, -0.2),
            radius: 1.1,
            colors: [Color(0xFF06223A), JarvisColors.background],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              const SizedBox(height: 16),
              const Text(
                'J.A.R.V.I.S.',
                style: TextStyle(
                  color: JarvisColors.cyan,
                  fontSize: 22,
                  letterSpacing: 8,
                  fontWeight: FontWeight.w300,
                ),
              ),
              const Spacer(),
              GestureDetector(
                onTap: _toggleListen,
                child: JarvisOrb(state: _orb, size: 300),
              ),
              const Spacer(),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: Text(
                  _status,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: JarvisColors.cyanDim,
                    fontSize: 12,
                    letterSpacing: 2,
                  ),
                ),
              ),
              Container(
                height: 90,
                width: double.infinity,
                margin: const EdgeInsets.all(20),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: JarvisColors.panel.withOpacity(0.6),
                  border: Border.all(
                      color: JarvisColors.cyan.withOpacity(0.4)),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  _transcript.isEmpty ? 'Tap the core to speak.' : _transcript,
                  style: const TextStyle(color: Colors.white70, fontSize: 16),
                ),
              ),
              const SizedBox(height: 12),
            ],
          ),
        ),
      ),
    );
  }
}
