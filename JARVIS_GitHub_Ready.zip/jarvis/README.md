# JARVIS — Flutter Android starter project

This is the first buildable stage of the JARVIS personal-assistant app. It currently contains the futuristic home screen, animated orb, and tap-to-speak speech recognition interface. It is **not yet a complete AI assistant**: Gemini responses, Firebase memory, spoken replies, always-on wake-word detection, WhatsApp automation, and smart-home integrations still need to be implemented.

## Build an Android APK using GitHub (phone-friendly)

1. Extract this ZIP on your Android phone. The extracted folder is named `jarvis`.
2. Open GitHub in Chrome. Create a repository named `jarvis-ai` and choose the `main` branch.
3. In the empty repository, choose **Add file → Upload files**.
4. Open the extracted `jarvis` folder and upload its **contents** (not the outer `jarvis` folder). Make sure the hidden `.github` folder is included. It contains the APK build workflow at `.github/workflows/build.yml`.
5. Commit the files to `main`.
6. Open the repository's **Actions** tab. If prompted, enable Actions. Select **Build JARVIS APK** and choose **Run workflow** if the workflow has not already started from the upload commit.
7. When the run finishes successfully, open it and find **Artifacts**. Download `jarvis-release-apk` and extract it. The APK is `app-release.apk`.
8. Open the APK on your phone and approve installation from that source if Android asks.

## Why Gradle wrapper files are not included

The GitHub Actions workflow generates the standard Gradle wrapper from the official Flutter project template on the cloud runner when needed. This avoids shipping generated wrapper binaries in this source ZIP. You do not need a computer to run that workflow.

## Current features

- Flutter Android application shell
- Dark futuristic JARVIS theme
- Animated orb with idle/listening/thinking/speaking visual states
- Tap-to-start / tap-to-stop speech recognition using the device speech service
- Displays recognized speech text

## Important limitations

- Speech recognition only transcribes what you say; it does not yet send the text to an AI model or speak an answer.
- The app does not listen continuously for “Hey JARVIS”. Android background microphone restrictions and battery policies require a separate, carefully designed implementation.
- Phone, calling, WhatsApp, camera, reminders, Firebase, Gemini, and smart-home features are not implemented yet.
- The release APK produced by this workflow is debug-signed for personal testing. It is not a Play Store release build.
- The workflow has been prepared but has **not been executed in this environment**. A successful GitHub Actions run is needed to verify the APK build.

## Versions configured

- Flutter: 3.27.4
- Java: 17
- Android Gradle Plugin: 8.1.0
- Gradle distribution: 8.3
- Kotlin: 1.8.22
- Speech recognition package: `speech_to_text` 7.0.0
